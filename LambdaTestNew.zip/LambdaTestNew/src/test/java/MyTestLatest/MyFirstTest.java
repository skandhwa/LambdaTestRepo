package MyTestLatest;

import java.net.MalformedURLException;
import java.net.URL;
import java.util.HashMap;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.testng.Assert;
import org.testng.annotations.Test;

public class MyFirstTest {
	
	@Test
	public void demoTest() throws MalformedURLException, InterruptedException
	{
		ChromeOptions browserOptions = new ChromeOptions();
		browserOptions.setPlatformName("Windows 10");
		browserOptions.setBrowserVersion("123.0");
		HashMap<String, Object> ltOptions = new HashMap<String, Object>();
		ltOptions.put("username", "saurabhkandhway91");
		ltOptions.put("accessKey", "SgkSPRtqnmJrVlY4WEJi7mZKyGYtgPPr3UCEUJZdBfl0LntBBx");
		ltOptions.put("visual", true);
		ltOptions.put("video", true);
		ltOptions.put("resolution", "1600x1200");
		ltOptions.put("build", "MySeleniumBuild");
		ltOptions.put("project", "LatestProject");
		ltOptions.put("w3c", true);
		ltOptions.put("plugin", "java-java");
		browserOptions.setCapability("LT:Options", ltOptions);
		WebDriver driver=new RemoteWebDriver(new URL("https://hub.lambdatest.com/wd/hub"),browserOptions);
		driver.get("https://www.google.com");
	String Title=	driver.getTitle();
	Assert.assertEquals(Title, "Google");
	Thread.sleep(7000);
	driver.close();
	}
	
	

}
