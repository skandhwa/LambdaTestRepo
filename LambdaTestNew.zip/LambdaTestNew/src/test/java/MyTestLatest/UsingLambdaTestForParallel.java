package MyTestLatest;

import java.net.MalformedURLException;
import java.net.URL;
import java.util.HashMap;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.edge.EdgeOptions;
import org.openqa.selenium.firefox.FirefoxOptions;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.testng.Assert;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

public class UsingLambdaTestForParallel {
	@Parameters({"browserName","browserVersion","osVersion"})
	@Test
	public void myTest2(String browserName,String browserVersion,String osVersion) throws MalformedURLException, InterruptedException
	{
		
		
        WebDriver driver=null;
		
		HashMap<String, Object> ltOptions = new HashMap<String, Object>();
		
		ltOptions.put("username", "saurabhkandhway91");
		ltOptions.put("accessKey", "SgkSPRtqnmJrVlY4WEJi7mZKyGYtgPPr3UCEUJZdBfl0LntBBx");
		ltOptions.put("visual", true);
		ltOptions.put("video", true);
		ltOptions.put("resolution", "1600x1200");
		ltOptions.put("build", "MySeleniumBuild");
		ltOptions.put("project", "LatestProject");
		ltOptions.put("w3c", true);
		ltOptions.put("plugin", "java-java");
		
		
		
		if (browserName.equalsIgnoreCase("Chrome")) {
		
			ChromeOptions browserOptions = new ChromeOptions();
			
			browserOptions.setPlatformName(osVersion);
			
			browserOptions.setBrowserVersion(browserVersion);
		
			browserOptions.setCapability("LT:Options", ltOptions);
			
			driver=new RemoteWebDriver(new URL("https://hub.lambdatest.com/wd/hub"),browserOptions);
			
			
		}
		else if(browserName.equalsIgnoreCase("Firefox")){
			
			FirefoxOptions browserOptions = new FirefoxOptions();
			
			browserOptions.setPlatformName(osVersion);
			
			browserOptions.setBrowserVersion(browserVersion);
		
			browserOptions.setCapability("LT:Options", ltOptions);
			
			driver=new RemoteWebDriver(new URL("https://hub.lambdatest.com/wd/hub"), browserOptions);
			
		}
		else if(browserName.equalsIgnoreCase("Edge")){
			
			EdgeOptions browserOptions = new EdgeOptions();
			
			browserOptions.setPlatformName(osVersion);
			
			browserOptions.setBrowserVersion(browserVersion);
		
			browserOptions.setCapability("LT:Options", ltOptions);
			
			driver=new RemoteWebDriver(new URL("https://hub.lambdatest.com/wd/hub"), browserOptions);
		}
		
	
		driver.get("https://www.google.com");
		String Title=	driver.getTitle();
		Assert.assertEquals(Title, "Google");
		Thread.sleep(7000);
		driver.close();
		
	
	
		
	}

}
